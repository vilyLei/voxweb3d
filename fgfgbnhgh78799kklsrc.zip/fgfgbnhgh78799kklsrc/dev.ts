

//  import * as VatParallaxMap2 from "./voxvat/demo/VatParallaxMap2";
//  import Demo = VatParallaxMap2.voxvat.demo.VatParallaxMap2;

//  import * as DemoBase from "./demo2d/DemoBase";
//  import Demo = DemoBase.demo2d.DemoBase;

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

//  import * as DemoPathWalk from "./voxnav/DemoPathWalk";
//  import Demo = DemoPathWalk.voxnav.DemoPathWalk;

//  import * as DemoTriNav from "./voxnav/DemoTriNav";
//  import Demo = DemoTriNav.voxnav.DemoTriNav;


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

//  import * as FixProjMotion from "./motionDemo/FixProjMotion";
//  import Demo = FixProjMotion.motionDemo.FixProjMotion;

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

//  import * as DemoQuadLine from "./demo/DemoQuadLine";
//  import Demo = DemoQuadLine.demo.DemoQuadLine;

//  import {DemoObjModel as Demo} from "./demo/DemoObjModel";

//  import * as DemoTexture from "./demo/DemoTexture";
//  import Demo = DemoTexture.demo.DemoTexture;

//  import * as DemoCamVisibleTest from "./demo/DemoCamVisibleTest";
//  import Demo = DemoCamVisibleTest.demo.DemoCamVisibleTest;

//  import * as DemoSphereOcclusion from "./voxocc/demo/DemoSphereOcclusion";
//  import Demo = DemoSphereOcclusion.voxocc.demo.DemoSphereOcclusion;

//  import * as DemoQuadOcclusion from "./voxocc/demo/DemoQuadOcclusion";
//  import Demo = DemoQuadOcclusion.voxocc.demo.DemoQuadOcclusion;

//  import * as DemoQuadHoleOcc from "./voxocc/demo/DemoQuadHoleOcc";
//  import Demo = DemoQuadHoleOcc.voxocc.demo.DemoQuadHoleOcc;

//  import * as DemoBoxOcclusion from "./voxocc/demo/DemoBoxOcclusion";
//  import Demo = DemoBoxOcclusion.voxocc.demo.DemoBoxOcclusion;

//  import * as DemoOccBoxWall from "./voxocc/demo/DemoOccBoxWall";
//  import Demo = DemoOccBoxWall.voxocc.demo.DemoOccBoxWall;

//  import * as DemoOccBoxWall2 from "./voxocc/demo/DemoOccBoxWall2";
//  import Demo = DemoOccBoxWall2.voxocc.demo.DemoOccBoxWall2;

//  import * as DemoRayTest from "./demo/DemoRayTest";
//  import Demo = DemoRayTest.demo.DemoRayTest;

//  import * as DemoSubScene from "./demo/DemoSubScene";
//  import Demo = DemoSubScene.demo.DemoSubScene;

//  import * as DemoEntityBounds from "./demo/DemoEntityBounds";
//  import Demo = DemoEntityBounds.demo.DemoEntityBounds;

//  import * as DemoScene from "./demo/DemoScene";
//  import Demo = DemoScene.demo.DemoScene;

//  import * as DemoSphScreenRect from "./demo/DemoSphScreenRect";
//  import Demo = DemoSphScreenRect.demo.DemoSphScreenRect;

//  import * as DemoGeom from "./demo/DemoGeom";
//  import Demo = DemoGeom.demo.DemoGeom;

//  import * as DemoPreDepth from "./demo/DemoPreDepth";
//  import Demo = DemoPreDepth.demo.DemoPreDepth;

//  import * as DemoRTTHalfSize from "./demo/DemoRTTHalfSize";
//  import Demo = DemoRTTHalfSize.demo.DemoRTTHalfSize;

//  import {DemoRTT as Demo} from "./demo/DemoRTT";

//  import {DemoFloatRTT as Demo} from "./demo/DemoFloatRTT";

//  import * as DemoMRT2 from "./demo/DemoMRT2";
//  import Demo = DemoMRT2.demo.DemoMRT2;

//  import { DemoFBOInstance as Demo } from "./demo/DemoFBOInstance";

//  import {DemoCubeMapMRT as Demo} from "./demo/DemoCubeMapMRT";

//  import {DemoFrustrum as Demo} from "./demo/DemoFrustrum";

//  import * as DemoScreenPingpongBlur from "./demo/DemoScreenPingpongBlur";
//  import Demo = DemoScreenPingpongBlur.demo.DemoScreenPingpongBlur;

//  import {DemoDepthBlur as Demo} from "./demo/DemoDepthBlur";

//  import * as DemoDepthBlur2 from "./demo/DemoDepthBlur2";
//  import Demo = DemoDepthBlur2.demo.DemoDepthBlur2;

//  import {DemoDepthTex as Demo} from "./demo/DemoDepthTex";

//  import * as DemoPNG from "./example/DemoPNG";
//  import Demo = DemoPNG.example.DemoPNG;

//  import * as DemoRTTCircle from "./demo/DemoRTTCircle";
//  import Demo = DemoRTTCircle.demo.DemoRTTCircle;

//  import {DemoLargeVtx as Demo} from "./large/DemoLargeVtx";

//  import * as VatParallaxMap2 from "./voxvat/demo/VatParallaxMap2";
//  import Demo = VatParallaxMap2.voxvat.demo.VatParallaxMap2;

//  import * as DemoFBOBlit from "./demo/DemoFBOBlit";
//  import Demo = DemoFBOBlit.demo.DemoFBOBlit;

//  import * as DemoPartRender from "./demo/DemoPartRender";
//  import Demo = DemoPartRender.demo.DemoPartRender;

//  import * as DemoLargeVtx from "./large/DemoLargeVtx";
//  import Demo = DemoLargeVtx.large.DemoLargeVtx;

//  import * as TwoTexture from "./example/TwoTexture";
//  import Demo = TwoTexture.example.TwoTexture;

//  import * as MipmapTexture from "./example/MipmapTexture";
//  import Demo = MipmapTexture.example.MipmapTexture;

//  import {DemoThread as Demo} from "./demo/DemoThread";

//  import * as DemoThreadSchedule from "./demo/DemoThreadSchedule";
//  import Demo = DemoThreadSchedule.demo.DemoThreadSchedule;

//  import * as DemoMatComputer from "./demo/DemoMatComputer";
//  import Demo = DemoMatComputer.demo.DemoMatComputer;

//  import * as DemoThreadConcurrent from "./demo/DemoThreadConcurrent";
//  import Demo = DemoThreadConcurrent.demo.DemoThreadConcurrent;

//  import * as DemoMatContainer from "./demo/DemoMatContainer";
//  import Demo = DemoMatContainer.demo.DemoMatContainer;

//  import * as DemoMatTransThread from "./demo/DemoMatTransThread";
//  import Demo = DemoMatTransThread.demo.DemoMatTransThread;

//  import * as DemoDrawGroup from "./demo/DemoDrawGroup";
//  import Demo = DemoDrawGroup.demo.DemoDrawGroup;

//  import {DemoDeepTransparent as Demo} from "./demo/DemoDeepTransparent";

//  import * as DemoGpuVtxMana from "./demo/DemoGpuVtxMana";
//  import Demo = DemoGpuVtxMana.demo.DemoGpuVtxMana;

//  import * as DemoGpuTexMana from "./demo/DemoGpuTexMana";
//  import Demo = DemoGpuTexMana.demo.DemoGpuTexMana;

//  import * as DemoMaterial from "./demo/DemoMaterial";
//  import Demo = DemoMaterial.demo.DemoMaterial;

//  import * as DemoVtx from "./demo/DemoVtx";
//  import Demo = DemoVtx.demo.DemoVtx;

//  import * as DemoSwapProcess from "./demo/DemoSwapProcess";
//  import Demo = DemoSwapProcess.demo.DemoSwapProcess;

//  import {DemoDelEntity as Demo} from "./demo/DemoDelEntity";

//  import * as DemoText2D from "./demo/DemoText2D";
//  import Demo = DemoText2D.demo.DemoText2D;

//  import {DemoTexUpdate as Demo} from "./demo/DemoTexUpdate";

//  import * as DemoKeyboardEvt from "./demo/DemoKeyboardEvt";
//  import Demo = DemoKeyboardEvt.demo.DemoKeyboardEvt;

//  import {DemoParticle as Demo} from "./demo/DemoParticle";

//  import {DemoParticleMixTex as Demo} from "./demo/DemoParticleMixTex";

//  import {DemoParticleGroup as Demo} from "./demo/DemoParticleGroup";

//  import {DemoParticleEruption as Demo} from "./demo/DemoParticleEruption";

//  import {DemoParticleClips as Demo} from "./demo/DemoParticleClips";

//  import {DemoContainer as Demo} from "./demo/DemoContainer";

//  import * as DemoContainerTransform from "./demo/DemoContainerTransform";
//  import Demo = DemoContainerTransform.demo.DemoContainerTransform;

//  import * as DemoFontText from "./demo/DemoFontText";
//  import Demo = DemoFontText.demo.DemoFontText;

//  import * as DemoDivControl from "./demo/DemoDivControl";
//  import Demo = DemoDivControl.demo.DemoDivControl;

//  import {DemoLockDrawEntity as Demo} from "./demo/DemoLockDrawEntity";

//  import {DemoEmptyRenderer as Demo} from "./demo/DemoEmptyRenderer";

//  import {DemoEmptyRendererScene as Demo} from "./demo/DemoEmptyRendererScene";

//  import {DemoAPlane as Demo} from "./demo/DemoAPlane";

//  import {DemoPrimitive as Demo} from "./demo/DemoPrimitive";

//  import {DemoFlexMesh as Demo} from "./demo/DemoFlexMesh";

//  import * as DemoFlexPipe from "./demo/DemoFlexPipe";
//  import Demo = DemoFlexPipe.demo.DemoFlexPipe;

//  import * as DemoVSTexture from "./demo/DemoVSTexture";
//  import Demo = DemoVSTexture.demo.DemoVSTexture;

//  import * as DemoVSTexturePos from "./demo/DemoVSTexturePos";
//  import Demo = DemoVSTexturePos.demo.DemoVSTexturePos;

//  import {DemoFloatTex as Demo} from "./demo/DemoFloatTex";

//  import {DemoCubeFloatTex as Demo} from "./demo/DemoCubeFloatTex";

//  import * as DemoFloatTex2 from "./example/DemoFloatTex2";
//  import Demo = DemoFloatTex2.demo.DemoFloatTex2;

//  import * as DemoBoxGroupTrack from "./demo/DemoBoxGroupTrack";
//  import Demo = DemoBoxGroupTrack.demo.DemoBoxGroupTrack;

//  import * as DemoFaceDirec from "./demo/DemoFaceDirec";
//  import Demo = DemoFaceDirec.demo.DemoFaceDirec;

//  import {DemoMotion as Demo} from "./demo/DemoMotion";

//  import {DemoMixProgress as Demo} from "./demo/DemoMixProgress";

//  import {DemoRenderSort as Demo} from "./demo/DemoRenderSort";

//  import {DemoThread as Demo} from "./thread/example/DemoThread";

//  import {DemoOrtho as Demo} from "./demo/DemoOrtho";

//  import {DemoMouseEvent as Demo} from "./demo/DemoMouseEvent";

//  import {DemoMultiRendererScene as Demo} from "./demo/DemoMultiRendererScene";

//  import {DemoMultiRendererScene2 as Demo} from "./demo/DemoMultiRendererScene2";

//  import {DemoMultiGpuContext as Demo} from "./demo/DemoMultiGpuContext";

//  import {DemoMultiRenderer as Demo} from "./demo/DemoMultiRenderer";

//  import {DemoOrthoSubScene as Demo} from "./demo/DemoOrthoSubScene";

//  import {DemoOrthoBtn as Demo} from "./demo/DemoOrthoBtn";

//  import {DemoMobileEvt as Demo} from "./demo/DemoMobileEvt";

//  import {DemoMouseDrag as Demo} from "./demo/DemoMouseDrag";

//  import {DemoCameraSwing as Demo} from "./demo/DemoCameraSwing";

//  import {DemoCamVisibleTest as Demo} from "./demo/DemoCamVisibleTest";

//  import {DemoHdrCylindricalMap as Demo} from "./demo/DemoHdrCylindricalMap";

//  import {DemoRGBETex as Demo} from "./demo/DemoRGBETex";

//  import {DemoGLState as Demo} from "./demo/DemoGLState";

//  import {DemoStencil as Demo} from "./demo/DemoStencil";

//  import {DemoBlendMode as Demo} from "./demo/DemoBlendMode";

//  import {DemoFileSystem as Demo} from "./demo/DemoFileSystem";

//  import {DemoPreDepthTransparent as Demo} from "./demo/DemoPreDepthTransparent";

//  import {DemoObj3DModule as Demo} from "./demo/DemoObj3DModule";

//  import {DemoCubeMap as Demo} from "./demo/DemoCubeMap";

//  import {DemoRTTCamera as Demo} from "./demo/DemoRTTCamera";

//  import {DemoDeepTransparent2 as Demo} from "./demo/DemoDeepTransparent2";

//  import {DemoPingpongBlur as Demo} from "./demo/DemoPingpongBlur";

//  import {DemoRTTLod as Demo} from "./demo/DemoRTTLod";

//  import {DemoRTTCube as Demo} from "./demo/DemoRTTCube";

//  import {DemoProjectPlane as Demo} from "./demo/DemoProjectPlane";

//  import {DemoMirrorPlane as Demo} from "./demo/DemoMirrorPlane";

//  import {DemoDraco as Demo} from "./demo/DemoDraco";

//  import {DemoMRT as Demo} from "./demo/DemoMRT";

//  import {DemoDepthTex as Demo} from "./demo/DemoDepthTex";

///////////////////////////////////////////////////////////////////////////////
/////////////////////////////     shadow    ///////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

//  import {DemoBase as Demo} from "./shadow/vsm/DemoBase";

//  import {DemoVSM as Demo} from "./shadow/vsm/DemoVSM";

//  import {DemoVSMModule as Demo} from "./shadow/vsm/DemoVSMModule";

//  import {DemoSSAO as Demo} from "./shadow/ssao/DemoSSAO";

//  import {DemoSSAO2 as Demo} from "./shadow/ssao/DemoSSAO2";

//  import {DemoSSAO3 as Demo} from "./shadow/ssao/DemoSSAO3";

//  import {DemoSSAO4 as Demo} from "./shadow/ssao/DemoSSAO4";

///////////////////////////////////////////////////////////////////////////////
/////////////////////////////     light    ////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

//  import {DemoAdsLight as Demo} from "./demo/DemoAdsLight";

//  import {DemoTextureCubeUV as Demo} from "./pbr/DemoTextureCubeUV";

//  import {DemoLighting as Demo} from "./pbr/DemoLighting";

//  import {DemoEnvLighting as Demo} from "./pbr/DemoEnvLighting";

//  import {DemoModulePBR as Demo} from "./pbr/DemoModulePBR";

//  import {DemoLightsPBR as Demo} from "./pbr/DemoLightsPBR";

//  import {DemoDefaultPBR as Demo} from "./pbr/DemoDefaultPBR";

//  import {DemoDefaultPBR2 as Demo} from "./pbr/DemoDefaultPBR2";

//  import {DemoDefaultPBR3 as Demo} from "./pbr/DemoDefaultPBR3";

//  import {DemoPBR as Demo} from "./pbr/DemoPBR";

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////     APP    ////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

//  import * as LegRole from "./app/LegRole";
//  import Demo = LegRole.app.LegRole;

//  import * as BoFrame from "./app/BoFrame";
//  import Demo = BoFrame.app.BoFrame;

//  import {RbtDrama as Demo} from "./app/RbtDrama";

//  import * as DensityStatistics from "./app/density/DensityStatistics";
//  import Demo = DensityStatistics.app.density.DensityStatistics;

///////////////////////////////////////////////////////////////////////////////
/////////////////////////////     gltf    /////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

//  import {DemoGLTF as Demo} from "./gltf/DemoGLTF";

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////     UI     ////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

//  import {DemoOrthoBtn as Demo} from "./orthoui/demos/DemoOrthoBtn";

//  import {DemoOrthoPanel as Demo} from "./orthoui/demos/DemoOrthoPanel";

import {DemoUITexAtlas as Demo} from "./orthoui/demos/DemoUITexAtlas";

///////////////////////////////////////////////////////////////////////////////

let demoIns: Demo = new Demo();
let ins: any = demoIns;
if (ins.runBegin != undefined) {
    function main1(): void {
        console.log("------ demo --- init ------");
        ins.initialize();
        function mainLoop(now: any): void {
            ins.runBegin();
            ins.run();
            ins.runEnd();
            window.requestAnimationFrame(mainLoop);
        }
        window.requestAnimationFrame(mainLoop);
        console.log("------ demo --- running ------");
    }
    //
    main1();
}
else {
    function main2(): void {
        console.log("------ demo --- init ------");
        demoIns.initialize();
        function mainLoop(now: any): void {
            demoIns.run();
            window.requestAnimationFrame(mainLoop);
        }
        window.requestAnimationFrame(mainLoop);
        console.log("------ demo --- running ------");
    }
    //
    main2();
}
