/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2022 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/

export default interface IAbstractShader
{
    vert: string;
    vert_head: string;
    vert_body: string;
    frag: string;
    frag_head: string;
    frag_body: string;
}