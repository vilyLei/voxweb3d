/*

import * as VatParallaxMap2 from "./voxvat/demo/VatParallaxMap2";
import Demo = VatParallaxMap2.voxvat.demo.VatParallaxMap2;

let demoIns:Demo = new Demo();
function main():void
{
    console.log("-------------------------------- vat sys --- init ------------------------------------");
    demoIns.initialize();
    function mainLoop(now:any):void
    {
        demoIns.run();
        window.requestAnimationFrame(mainLoop);
    }
    window.requestAnimationFrame(mainLoop);
    console.log("-------------------------------- vat sys --- running -------------------------------------"); 
}
//
main();
*/