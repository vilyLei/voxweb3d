/***************************************************************************/
/*                                                                         */
/*  Copyright 2018-2022 by                                                 */
/*  Vily(vily313@126.com)                                                  */
/*                                                                         */
/***************************************************************************/


enum CampType
{
    Free,
    Red,
    Blue,
    Green
}
enum CampFindMode
{
    Default,
    XOZ
    
}

export {CampType,CampFindMode};