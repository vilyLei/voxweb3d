

export namespace voxvat
{
    export namespace demo
    {
        export namespace scene
        {
            export class MaterialParam
            {
                uscale:number = 1.0;
                vscale:number = 1.0;
            }
        }
    }
}